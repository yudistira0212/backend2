import { Sequelize } from "sequelize";

const db = new Sequelize("presensiunipa", "presensiunipa", "YHc9KrIGd8V0d5V", {
  host: "	presensi.unipa.ac.id",
  dialect: "mysql",
});

export default db;
